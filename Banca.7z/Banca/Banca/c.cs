﻿using System;

namespace Banca
{
    internal class c
    {
        public static explicit operator c(object v)
        {
            throw new NotImplementedException();
        }
    }
}