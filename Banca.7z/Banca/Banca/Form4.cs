﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banca
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            label4.Visible = false;
            label6.Visible = false;
            textBox2.Visible = false;

            
        }
        int gheseo = Form3.GetChiseo();
        
        private void Label3_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {
            label4.Visible = false;
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            label4.Visible = false;
        }

        private void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Visible = true;
            label4.Visible = false;
            label4.Visible = false;
        }

        private void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Visible = false;
            label4.Visible = false;
        }

        private void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Visible = false;
            label4.Visible = false;
        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Form Form5 = new Form5();
            Form5.Show(this);
            this.Visible = false;
        }

       
        private void Button1_Click(object sender, EventArgs e)
        {
            double importo = 0;
            if (textBox1.Text == "")
            {
                MessageBox.Show("Controlla i campi");
            }
            else
            {
                if(radioButton1.Checked == true)//deposito
                {
                    importo = Convert.ToDouble(textBox1.Text);
                    double vecchiosaldo = ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo();
                    ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].AggiungiOperazione(importo, "Deposito", Convert.ToString(dateTimePicker1.Value));
                    importo = vecchiosaldo + importo;
                    ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].SetSaldo(importo);
                    label4.Visible = true;
                    label4.Text = "Deoposito eseguito con successo";
                }
                bool s = false;
                if (radioButton2.Checked == true)//prelievo
                {
                    importo = Convert.ToInt32(textBox1.Text);
                    string tipo = ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetTipoConto();

                    if(tipo == "Conto Standard")
                    {
                        double appoggio = ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo() - 1.30;
                        if ((appoggio < 0))
                        {
                            MessageBox.Show("Fondi insufficenti");
                        }
                        else
                        {
                            ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].SetSaldo(appoggio);
                        }

                    }
                    if (tipo == "Conto Aziende")
                    {
                        double appoggio = ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo() - 1.80;
                        if ((appoggio < 0))
                        {
                            MessageBox.Show("Fondi insufficenti");
                        }
                        else
                        {
                            ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].SetSaldo(appoggio);
                        }
                    }
                    
                    if (importo > ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo())
                    {
                        MessageBox.Show("Fondi insufficenti");
                    }
                    else
                    {
                        importo = Convert.ToInt32(textBox1.Text);

                        double vecchiosaldo = ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo();
                        ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].AggiungiOperazione(importo, "Prelievo", Convert.ToString(dateTimePicker1.Value));
                        importo = vecchiosaldo - importo;
                        ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].SetSaldo(importo);
                        label4.Visible = true;
                        label4.Text = "Prelievo eseguito ritirare i soldi";
                    }
                }
                if (radioButton3.Checked == true)//bonifico
                {
                    string tipo = ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetTipoConto();

                    if (tipo == "Conto Aziende")
                    {
                        double appoggio = ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo() - 2;
                        if ((appoggio < 0))
                        {
                            MessageBox.Show("Fondi insufficenti");
                        }
                        else
                        {
                            ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].SetSaldo(appoggio);
                        }
                    }
                    if (tipo == "Conto Standard")
                    {
                        double appoggio = ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo() - 1.50;
                        if ((appoggio < 0))
                        {
                            MessageBox.Show("Fondi insufficenti");
                        }
                        else
                        {
                            ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].SetSaldo(appoggio);
                        }
                    }
                    string iban = textBox2.Text;
                    bool cè = false;
                    int beneficiario = 0;
                    for(int z = 0;z< ((Owner as Form3).Owner as Form1).Arrayconti.Length; z++)
                    {
                        if(((Owner as Form3).Owner as Form1).Arrayconti[z].GetIban() == iban)
                        {
                            cè = true;
                            beneficiario = z;
                        }
                        label2.Text = Convert.ToString(((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo());

                    }
                    double saldocliente = ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo();
                    if (cè == true && saldocliente >= Convert.ToInt32(textBox1.Text))
                    {
                        saldocliente = saldocliente - Convert.ToInt32(textBox1.Text);
                        ((Owner as Form3).Owner as Form1).Arrayconti[gheseo].SetSaldo(saldocliente);
                        double somma = ((Owner as Form3).Owner as Form1).Arrayconti[beneficiario].GetSaldo() + Convert.ToDouble(textBox1.Text);
                        ((Owner as Form3).Owner as Form1).Arrayconti[beneficiario].SetSaldo(somma);
                        label4.Visible = true;
                        label4.Text = "Bonifico avvenuto con successo";
                        label2.Text = Convert.ToString(((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo());
                    }
                    else
                    {
                        MessageBox.Show("Cliente inesistente");
                    }
                }
                label2.Text = Convert.ToString(((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo());
            }
            label2.Text = Convert.ToString(((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo());
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Owner.Visible = true;

            this.Visible = false;
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            label2.Text = (((Owner as Form3).Owner as Form1).Arrayconti[gheseo].GetSaldo()).ToString();
        }
    }
}
