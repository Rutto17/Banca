﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banca
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            textBox5.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
        }

        
        
        static int chiseo = 0;

        public static int GetChiseo()
        {
            return chiseo;
        }
        private void Button2_Click(object sender, EventArgs e)
        {
            Owner.Visible = true;           
            this.Visible = false;
        }

        private void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label6.Visible = false;

            if (radioButton1.Checked == true)
            {
                
                textBox5.Visible = false;
                label5.Visible = false;
            }
            if (radioButton2.Checked == true)
            {
                
                textBox5.Visible = true;
                label5.Visible = true;
            }
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            label6.Visible = false;

        }

        private void RadioButton1_CheckedChanged_1(object sender, EventArgs e)
        {
            label6.Visible = false;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string intest1 = textBox1.Text;
            string intest2 = textBox5.Text;
            string codice = textBox2.Text;

            string nume = intest1 + " " + intest2;

            for(int i = 0; i < (Owner as Form1).Contatore; i++)
            {
                string s = (Owner as Form1).Arrayconti[i].GetNome();
                //string s2 = c[i].GetIndirizzo();
                string s3 = (Owner as Form1).Arrayconti[i].GetNumeroConto();
                if (s == nume && s3 == codice)
                {
                    chiseo = i;
                    Form Form4 = new Form4();
                    Form4.Show(this);
                    this.Visible = false;
                }
                else
                {
                    label6.Visible = true;
                    label6.Text = "Codice e/o nome utente non valido";
                }
            }
        }

        private void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label6.Visible = false;

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {
            label6.Visible = false;

        }
    }
}
