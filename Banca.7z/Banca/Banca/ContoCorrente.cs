﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Banca
{
    [Serializable]
    public class ContoCorrente
    {
        private double Bilancio = 0;
        public Operazioni[] operazioni = new Operazioni[5000];
        public int contOperazioni = 0;
        private string tipoconto;
        private double saldo;
        private int stato;
        private int età;
        private string indirizzo;
        private string nome;
        private string iban;
        private string numeroConto;

        public ContoCorrente() { }
        public ContoCorrente (string s,string c,string d,string e,int a,string tipo)
        {
            this.indirizzo = s;
            this.nome = c;
            this.numeroConto = d;
            this.iban = e;
            this.età = a;
            this.tipoconto = tipo;
        }
        public int GetcontOperazioni()
        {
            return contOperazioni;
        }
        public Operazioni[] GetArrOperazione()
        {
            return operazioni;
        }
        public string GetNome()
        {
            return nome;
        }
        public string GetTipoConto()
        {
            return tipoconto;
        }
        public string GetIban()
        {
            return iban;
        }
        public string GetIndirizzo()
        {
            return indirizzo;
        }
        public string GetNumeroConto()
        {
            return  numeroConto;
        }
        public double GetSaldo()
        {
            return saldo;
        }
        public void SetSaldo(double s)
        {
             saldo = s;
        }
        public int GetStato()
        {
            return stato;
        }
        public int GetEtà()
        {
            return età;
        }
        public int GetContaOperazioni()
        {
            return contOperazioni;
        }
        public void AggiungiOperazione(double importo,string topos, string data)
        {
            operazioni[contOperazioni] = new Operazioni(importo,topos, data);
            contOperazioni++;
        }
    }
}