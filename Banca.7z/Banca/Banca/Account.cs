﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Banca
{
    public struct Account
    {
        public string nome;
        public string indirizzo;
        public string numeroConto;
        private ContoCorrente conto;
    }
}