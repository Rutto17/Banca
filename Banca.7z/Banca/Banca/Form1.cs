﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;

namespace Banca
{
    [Serializable]
    public partial class Form1 : Form
    {
        object[] fileDaSalvare = new object[2];
        public ContoCorrente[] Arrayconti
        { get;
          set; }
        public int Contatore { get; set; }
        public Form1()
        {
            InitializeComponent();
            Arrayconti = new ContoCorrente[500];
            Contatore = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

            Form Form2 = new Form2();
            Form2.Show(this);
            this.Visible = false;
        }


        private void Button2_Click(object sender, EventArgs e)
        {
            Form Form3 = new Form3();
            Form3.Show(this);
            this.Visible = false;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void DateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Button3_Click_1(object sender, EventArgs e)
        {
            string s = @"C:\Users\Davide\Desktop\Scuola\Informatica\Banca\Testo.wao";
            
            
                fileDaSalvare[0] = Arrayconti;
                fileDaSalvare[1] = Contatore;
                Stream file;
                
                if (File.Exists(s) == true)
                {
                    file = File.Open(s,FileMode.Open);
                }
                else
                {                   
                    file = File.Create(s + ".wao");
                }
                
                BinaryFormatter serializzatore = new BinaryFormatter();
                serializzatore.Serialize(file, fileDaSalvare);
                file.Close();
            


        }

        private void Button4_Click(object sender, EventArgs e)
        {
            string s = @"C:\Users\Davide\Desktop\Scuola\Informatica\Banca\Testo.wao";
            BinaryFormatter bf = new BinaryFormatter();
            Stream file = File.Open(s, FileMode.OpenOrCreate);
            var dati = (object[])bf.Deserialize(file);
            ContoCorrente[] c = (ContoCorrente[])dati[0];
            int cont = Convert.ToInt32(dati[1]);
            Arrayconti = c;
            Contatore = cont;
            file.Close();
        }


    }
    }

