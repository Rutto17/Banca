﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banca
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            label7.Visible = false;
            label8.Visible = false;
        }

        

        string indirizzo = "";
        public string intestatario1 = "";
        string intestatario2 = "";
        string iban = "";
        string tipo = "";
        int età;
        private void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                label7.Visible = false;
                textBox2.Visible = false;
                label4.Visible = false;
            }
            if (radioButton2.Checked == true)
            {
                label7.Visible = false;
                textBox2.Visible = true;
                label4.Visible = true;
            }
        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            bool h = false;
            if (textBox1.Text == "" || textBox1.Text == "  "|| 
                (textBox2.Text == "" && radioButton2.Checked == true)|| 
                (textBox2.Text == "  " && radioButton2.Checked == true)|| 
                textBox1.Text == "\n" || (textBox2.Text == "\n"
                && radioButton2.Checked == true))
            {
                MessageBox.Show("Riempire tutti i campi!");
            }
            else if (textBox1.Text.Contains(" "))
            {
                intestatario1 = textBox1.Text;
                intestatario2 = "";
            }
            if (radioButton2.Checked == true && textBox2.Text.Contains(" "))
            {
                intestatario2 = textBox2.Text;
            }
            if (textBox1.Text != "" && textBox3.Text != "" && comboBox1.Text != "")
            {
                età = Convert.ToInt32(textBox4.Text);
            }
                if (textBox1.Text != "" && textBox3.Text != "" && comboBox1.Text != "")
            {
                indirizzo = textBox3.Text;
                string id = "";
                Random random = new Random();
                for (int i = 0; i < 6; i++)
                {
                    id += (char)random.Next(97, 122);
                }
                
                string z = "";
                for(int i = 0; i < 10; i++)
                {
                    z = z + Convert.ToString(random.Next(0, 9));
                }
                if (comboBox1.Text == "" || (età > 30 && comboBox1.Text == "Conto Giovane") || età < 60 && comboBox1.Text == "Conto Over60")
                {
                    MessageBox.Show("Mettere tipo conto(standard,over 60....");
                     h = true;
                }
                else if ( h == false)
                {
                    intestatario1 = textBox1.Text;
                    intestatario2 = textBox2.Text;
                    label7.Visible = true;
                    label7.Text = "La tua password bancaria è: " + id;
                    tipo = comboBox1.Text;
                    iban = z;
                    label8.Visible = true;
                    label8.Text = "Il tuo Iban è: " + iban;
                    (Owner as Form1).Arrayconti[(Owner as Form1).Contatore] = new ContoCorrente(indirizzo, intestatario1 + " " + intestatario2, id, iban, età, tipo);
                    (Owner as Form1).Contatore++;
                }
            }
            else
            {
                MessageBox.Show("Ricontrollare i campi!");
            }
        
        }

        private void Button2_Click(object sender, EventArgs e)
        {

            Owner.Visible = true;
            this.Visible = false;
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            label7.Visible = false;
        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {
            label7.Visible = false;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {
            label7.Visible = false;
            label8.Visible = false;
        }
    }
}
