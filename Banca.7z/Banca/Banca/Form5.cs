﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banca
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        
        private void Button2_Click(object sender, EventArgs e)
        {
            Owner.Visible = true;
            
            this.Visible = false;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            ContoCorrente[] gino = (((Owner as Form4).Owner as Form3).Owner as Form1).Arrayconti;
            int chiè = Form3.GetChiseo();
            int conta = gino[chiè].GetContaOperazioni();
            Operazioni[] opera = gino[chiè].GetArrOperazione();
            int h = DateTime.Compare(dateTimePicker1.Value, dateTimePicker2.Value);
            if (h >= 0 )
            {
                dataGridView1.Rows.Clear();
                   /* string data1 = Convert.ToString(dateTimePicker1.Value);
                    string data2 = Convert.ToString(dateTimePicker2.Value);
                    int f2 = DateTime.Compare(Convert.ToDateTime(opera[chiè].GetData()), Convert.ToDateTime(data2));
                    int f1 = DateTime.Compare(Convert.ToDateTime(opera[chiè].GetData()), Convert.ToDateTime(data1));
                    if (f2 == -1 && f1 == -1)
                    {
                        MessageBox.Show("popopopopooooooopo");
                    }*/
                    for (int z = 0; z < conta; z++)
                    {
                        dataGridView1.Rows.Add();
                        for (int dove = 0; dove < 3; dove++)
                        {
                            string data = opera[z].GetData();
                            string tipo = opera[z].GetTipo();
                            double importo = opera[z].GetImporto();
                            if (dove == 0)
                            {
                                dataGridView1.Rows[z].Cells[dove].Value = data;
                            }
                            if (dove == 1)
                            {
                                dataGridView1.Rows[z].Cells[dove].Value = tipo;

                            }
                            if (dove == 2)
                            {
                                dataGridView1.Rows[z].Cells[dove].Value = Convert.ToString(importo);

                            }
                        }                          
                    }
               
            }
            else
            {
                MessageBox.Show("Inserire intervallo valido");
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
