﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Banca
{
    [Serializable]
    public class Operazioni
    {
        double importo;
        private string tipo;
        private string data;

        public Operazioni() { }
        public Operazioni(double z,string a,string b)
        {
            this.importo = z;
            this.tipo = a;
            this.data = b;
        }
        public double GetImporto()
        {
            return importo;
        }
        public string GetTipo()
        {
            return tipo;
        }
        public string GetData()
        {
            return data;
        }
    }
}